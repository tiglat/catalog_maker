//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CatalogMaker.rc
//
#define IDD_OPTIONSDLG                  101
#define IDD_VIEWDLG                     102
#define IDD_SORTDLG                     103
#define IDD_FORMATDLG                   104
#define IDD_ABOUTDLG                    105
#define IDI_ICON2                       110
#define IDC_TAB1                        1002
#define IDC_CHECK1                      1003
#define IDC_CHK_FORMAT_FILES            1004
#define IDC_CHK_APPLY_TO_DIRS           1005
#define IDC_CHK_DATE                    1006
#define IDC_CHK_TIME                    1007
#define IDC_CHK_ATTR                    1008
#define IDC_CHK_FULL_NAME               1009
#define IDC_CHK_EXT                     1010
#define IDC_CHK_FILE_NAME               1011
#define IDC_CHK_DIRECTORIES             1012
#define IDC_EDIT1                       1013
#define IDC_ED_FORMAT_WIDTH             1014
#define IDC_CHK_SIZE                    1015
#define IDC_CHK_SORT_DESC               1016
#define IDC_ED_FILE_TYPES               1017
#define IDC_CHK_FORMAT_ALL              1018
#define IDC_CHK_FORMAT_EXT              1019
#define IDC_RB_SORT_NAME                1020
#define IDC_RB_SORT_EXT                 1021
#define IDC_RB_SORT_SIZE                1022
#define IDC_RB_SORT_DATE                1023
#define IDC_BUTTON1                     1024
#define IDC_BUT_SAVE_OPT                1025
#define IDC_RB_SORT_UNSORTED            1026
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        126
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
